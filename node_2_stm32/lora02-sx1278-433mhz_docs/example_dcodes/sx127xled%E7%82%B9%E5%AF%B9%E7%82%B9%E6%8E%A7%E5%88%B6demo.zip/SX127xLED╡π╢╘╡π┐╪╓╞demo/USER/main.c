#include "stm32f10x.h"
#include "HAL_uart.h"
#include "usmart.h"
#include "string.h"
#include "radio.h"
#include "delay.h"

#define USE_BAND_433	//ѡ��һ��Ƶ��
#define USE_MODEM_LORA	//ѡ��loraģʽ

#if defined( USE_BAND_433 )

#define RF_FREQUENCY                                434000000 // Hz

#elif defined( USE_BAND_780 )

#define RF_FREQUENCY                                780000000 // Hz

#elif defined( USE_BAND_868 )

#define RF_FREQUENCY                                868000000 // Hz

#elif defined( USE_BAND_915 )

#define RF_FREQUENCY                                915000000 // Hz

#else
    #error "Please define a frequency band in the compiler options."
#endif

#define TX_OUTPUT_POWER                             20        // dBm

#if defined( USE_MODEM_LORA )

#define LORA_BANDWIDTH                              0         // [0: 125 kHz,
                                                              //  1: 250 kHz,
                                                              //  2: 500 kHz,
                                                              //  3: Reserved]
#define LORA_SPREADING_FACTOR                       7         // [SF7..SF12]
#define LORA_CODINGRATE                             1         // [1: 4/5,
                                                              //  2: 4/6,
                                                              //  3: 4/7,
                                                              //  4: 4/8]
#define LORA_PREAMBLE_LENGTH                        8         // Same for Tx and Rx
#define LORA_SYMBOL_TIMEOUT                         5         // Symbols
#define LORA_FIX_LENGTH_PAYLOAD_ON                  false
#define LORA_IQ_INVERSION_ON                        false

#elif defined( USE_MODEM_FSK )

#define FSK_FDEV                                    25e3      // Hz
#define FSK_DATARATE                                50e3      // bps
#define FSK_BANDWIDTH                               50e3      // Hz
#define FSK_AFC_BANDWIDTH                           83.333e3  // Hz
#define FSK_PREAMBLE_LENGTH                         5         // Same for Tx and Rx
#define FSK_FIX_LENGTH_PAYLOAD_ON                   false

#else
    #error "Please define a modem in the compiler options."
#endif

#define RX_TIMEOUT_VALUE                            1000
#define BUFFER_SIZE                                 64 // Define the payload size here

#define MSG                            "hello"

uint16_t BufferSize = BUFFER_SIZE;
uint8_t Buffer[BUFFER_SIZE];

int8_t RssiValue = 0;
int8_t SnrValue = 0;

/*!
 * Radio events function pointer
 */
static RadioEvents_t RadioEvents;

/*!
 * \brief Function to be executed on Radio Tx Done event
 */
void OnTxDone( void );

/*!
 * \brief Function to be executed on Radio Rx Done event
 */
void OnRxDone( uint8_t *payload, uint16_t size, int16_t rssi, int8_t snr );

/*!
 * \brief Function executed on Radio Tx Timeout event
 */
void OnTxTimeout( void );

/*!
 * \brief Function executed on Radio Rx Timeout event
 */
void OnRxTimeout( void );

/*!
 * \brief Function executed on Radio Rx Error event
 */
void OnRxError( void );

void uart1callBackTest(uint8_t data){
	u8 Res;
	Res =USART_ReceiveData(USART1);	//��ȡ���յ�������
		
	if((USART_RX_STA&0x8000)==0){//����δ���
		if(USART_RX_STA&0x4000){//���յ���0x0d
			if(Res!=0x0a)
				USART_RX_STA=0;//���մ���,���¿�ʼ
			else
				USART_RX_STA|=0x8000;	//��������� 
			
		}else{ //��û�յ�0X0D
			if(Res==0x0d)
				USART_RX_STA|=0x4000;
			else{
				USART_RX_BUF[USART_RX_STA&0X3FFF]=Res ;
				USART_RX_STA++;
				if(USART_RX_STA>(USART_REC_LEN-1))
					USART_RX_STA=0;//�������ݴ���,���¿�ʼ����	  
			}
		}
	}
}
uint8_t testFun(uint8_t num,char *str){
	printf("\r\ntestFun:%d-%s\r\n",num,str);
	printf("rssi:%d\r\n",SX1276ReadRssi(MODEM_LORA));
	return 2;
}

void ledInit(void)
{
	GPIO_InitTypeDef  GPIO_InitStructure;
	
	//��ʼ��led
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);	    //ʹ��ָ���˿�ʱ�ӣ�������Ϊ�˷���ABCȫ���ˣ�
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;	 //IO���ٶ�Ϊ50MHz�����ﲻ�ô��Σ�ֱ��д��������ٶ�50MHZ
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12;
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_Out_PP;	//����Ϊ�������
	GPIO_Init(GPIOB, &GPIO_InitStructure);	//��ʼ��GPIO
	
	//��ʼ������
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_IPU;//��������
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13;
	GPIO_Init(GPIOB, &GPIO_InitStructure);	//��ʼ��GPIO
}
int main(void)
{
	bool isMaster = true;		//һ������Ϊ����һ������Ϊ�ӻ�
	//bool isMaster = false;
	
	uint32_t count=0;
	
	delay_init();	    	 //��ʱ������ʼ��
	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);	//NVIC(�ж����ȼ�����)��������,ע��:���������������ֻ����һ��,���ú�Ҫ�޸�,�������ֺܶ�����
	HALUart1Init(115200,uart1callBackTest);
	ledInit();
	myPrintf(LEVEL_DEBUG,"init ok\r\n");
	if(isMaster){
		myPrintf(LEVEL_DEBUG,"this is master\r\n");
	}else{
		myPrintf(LEVEL_DEBUG,"this is slave\r\n");
	}
	usmart_dev.init(SystemCoreClock/1000000);	//��ʼ��USMART	
	
	// Radio initialization
  RadioEvents.TxDone = OnTxDone;
  RadioEvents.RxDone = OnRxDone;
  RadioEvents.TxTimeout = OnTxTimeout;
  RadioEvents.RxTimeout = OnRxTimeout;
  RadioEvents.RxError = OnRxError;

  Radio.Init( &RadioEvents );

  Radio.SetChannel( RF_FREQUENCY );

  Radio.SetTxConfig( MODEM_LORA, TX_OUTPUT_POWER, 0, LORA_BANDWIDTH,
                                   LORA_SPREADING_FACTOR, LORA_CODINGRATE,
                                   LORA_PREAMBLE_LENGTH, LORA_FIX_LENGTH_PAYLOAD_ON,
                                   true, 0, 0, LORA_IQ_INVERSION_ON, 3000 );
    
  Radio.SetRxConfig( MODEM_LORA, LORA_BANDWIDTH, LORA_SPREADING_FACTOR,
                                   LORA_CODINGRATE, 0, LORA_PREAMBLE_LENGTH,
                                   LORA_SYMBOL_TIMEOUT, LORA_FIX_LENGTH_PAYLOAD_ON,
                                   0, true, 0, 0, LORA_IQ_INVERSION_ON, true );

	if(!isMaster){
		Radio.Rx( RX_TIMEOUT_VALUE );
	}
	
  while( 1 ){
		if(isMaster){
			count=0;
			while(0==GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_13)){
				delay_ms(2);
				if(count++ > 50){//��������
					//������
					myPrintf(LEVEL_DEBUG,"sen msg\r\n");
					Radio.Send( (uint8_t *)MSG, strlen(MSG) );
					delay_ms( 3000 );
				}
			}
		}
  }
}

void OnTxDone( void )
{
	Radio.Sleep( );
	myPrintf(LEVEL_DEBUG,"TxDone\r\n");
}

void OnRxDone( uint8_t *payload, uint16_t size, int16_t rssi, int8_t snr )
{
	static bool ledStatus=false;
	Radio.Sleep( );
	memset(Buffer,0,BUFFER_SIZE);
	BufferSize = size;
	memcpy( Buffer, payload, BufferSize );
	RssiValue = rssi;
	SnrValue = snr;
	myPrintf(LEVEL_DEBUG,"RxDone\r\nrssi:%d\r\nsnr:%d\r\nsize:%d\r\ndata:payload:%s\r\n",rssi,snr,size,payload);
	
	if( strncmp( ( const char* )Buffer, ( const char* )MSG, 4 ) == 0 ){
		if(ledStatus){
			GPIO_ResetBits(GPIOB,GPIO_Pin_12);	//����͵�ƽ
		}else{
			GPIO_SetBits(GPIOB,GPIO_Pin_12);	//����ߵ�ƽ
		}
		ledStatus=!ledStatus;
	}
	
	Radio.Rx( RX_TIMEOUT_VALUE );
}

void OnTxTimeout( void )
{
	Radio.Sleep( );
	myPrintf(LEVEL_DEBUG,"TxTIMEOUT\r\n");
}

void OnRxTimeout( void )
{
	Radio.Sleep( );
	myPrintf(LEVEL_DEBUG,"RxTIMEOUT retry recive\r\n");
	Radio.Rx( RX_TIMEOUT_VALUE );
}

void OnRxError( void )
{
	Radio.Sleep( );
	myPrintf(LEVEL_DEBUG,"RxError  retry recive\r\n");
	Radio.Rx( RX_TIMEOUT_VALUE );
}

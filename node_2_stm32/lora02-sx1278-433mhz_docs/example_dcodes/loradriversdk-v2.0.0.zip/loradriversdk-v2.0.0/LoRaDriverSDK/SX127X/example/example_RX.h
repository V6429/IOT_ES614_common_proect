#ifndef __EXAMPLE_RX__
#define __EXAMPLE_RX__

void exampleRx(void);

#endif	//end of __EXAMPLE_RX__

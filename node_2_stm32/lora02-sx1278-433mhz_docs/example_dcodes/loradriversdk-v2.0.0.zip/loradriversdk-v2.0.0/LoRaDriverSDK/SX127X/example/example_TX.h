#ifndef __EXAMPLE_TX_H__
#define __EXAMPLE_TX_H__

void exampleTx(void);

#endif	//end of __EXAMPLE_TX_H__
